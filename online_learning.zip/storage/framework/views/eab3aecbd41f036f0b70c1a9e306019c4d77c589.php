    
    <?php $__env->startSection('title','Online Learning System : KBTC'); ?>
    <?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
       
        <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                    
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 last-item">
                            <div class="section-block">
                                <h3 >Course Content </h3>
                                <h4 class="text-danger"><span class="fas fa-download"></span> Course Resources</h4>
                            </div>
                            
                            <div class="accrodion-regular">
                                <div id="accordion3">
                                    <?php if(isset($sections)): ?>
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card mb-2">
                                        <div class="card-header" id="heading<?php echo e($section->id); ?>">
                                            <h5 class="mb-0">
                                               <button class="btn btn-link" data-toggle="collapse" data-target="#<?php echo e($section->id); ?>" aria-expanded="false" aria-controls="<?php echo e($section->id); ?>">
                                                 <span class="fas fa-angle-down mr-3"></span><?php echo e($section->title); ?>

                                             </button>       </h5>
                                        </div>
                                        <div id="<?php echo e($section->id); ?>" class="collapse" aria-labelledby="heading<?php echo e($section->id); ?>" data-parent="#accordion3">
                                            <div class="list-group">

                                            <?php if(isset($course_content)): ?>
                                            <?php $__currentLoopData = $course_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($temp->section_id == $section->id): ?>
                                                <?php if($temp->video_url): ?>
                                                <a href="course-content/<?php echo e($section->course_id); ?>&<?php echo e($temp->id); ?>" class="list-group-item list-group-item-action">
                                                    <label class="custom-control custom-checkbox green">
                                                    <input type="checkbox" checked="" class="custom-control-input"><span class="custom-control-label text-dark">Video 1</span>
                                                    </label>    
                                                    <p class="course-content-title">
                                                        <span class="fas fa-play-circle"></span>
                                                        12 mins
                                                    </p> 
                                                </a>
                                                <?php elseif($temp->assignment_url): ?>
                                                <a href="course-content/<?php echo e($section->course_id); ?>&<?php echo e($temp->id); ?>" class="list-group-item list-group-item-action">
                                                    <label class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input"><span class="custom-control-label text-dark">Assignment 1</span>
                                                    </label>    
                                                    <p class="course-content-title">
                                                        <span class="fas fa-file"></span>
                                                        Filename.txt
                                                    </p> 
                                                </a>
                                                <?php elseif($temp->presentation_url): ?>
                                                <a href="course-content/<?php echo e($section->course_id); ?>&<?php echo e($temp->id); ?>" class="list-group-item list-group-item-action">
                                                    <label class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input"><span class="custom-control-label text-dark">Presentation 1</span>
                                                    </label>    
                                                    <p class="course-content-title">
                                                        <span class="fas fa-file"></span>
                                                        Filename.txt
                                                    </p> 
                                                </a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
                </nav>
            </div>
       
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper-1">
            <div class="container course">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-7">
                        <div class="page-header">
                            <br>
                            <h2 class="pageheader-title">Course Name</h2>
                                        
                         </div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" style="margin-bottom:2rem;">
                        <ul id="myUL">
                            <li><span class="caret text-dark">Course Resourse</span>
                                <?php if(isset($sections)): ?>
                                <ul class="nested active">
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><span class="caret"><?php echo e($section->title); ?></span>
                                        <ul class="nested">

                                        <?php if(isset($course_content)): ?>
                                        <?php $__currentLoopData = $course_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($temp->section_id == $section->id): ?>
                                            <?php if($temp->video_url): ?>
                                            <li><a href="course-content/<?php echo e($section->course_id); ?>&<?php echo e($temp->id); ?>"><span class="fas fa-download text-primary"></span> Video 2</a></li>
                                            <?php elseif($temp->assignment_url): ?>
                                            <li><a href="course-content/<?php echo e($section->course_id); ?>&<?php echo e($temp->id); ?>"><span class="fas fa-download text-primary"></span> Assignment 1</a><a href="" class="upload"><span class="fas fa-upload text-danger"></span> Upload Your Assignment Here</a></li>
                                            <?php elseif($temp->presentation_url): ?>
                                            <li><a href="course-content/<?php echo e($section->course_id); ?>&<?php echo e($temp->id); ?>"><span class="fas fa-download text-primary"></span> Presentation file 2</a></li>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </ul>
                                    </li> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                </ul>
                                <?php endif; ?>
                            </li>
                        </ul>            
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <a href="course-content" class="btn btn-primary">Continue Course</a>
                </div>
                
                </div>
                
        </div>
            
        </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <div class="footer-1">
                <div class="container-fluid">
                    
                    <div class="row">

                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                             Copyright © 2020 Concept. All rights reserved. Dashboard by <a href="">Knowledge Lab Software Solution</a>.
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="text-md-right footer-links d-none d-sm-block">
                                <a href="javascript: void(0);">About</a>
                                <a href="javascript: void(0);">Support</a>
                                <a href="javascript: void(0);">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zaya\OneDrive\KBTC\online learning\online_learning\resources\views/student/pages/course-resource.blade.php ENDPATH**/ ?>