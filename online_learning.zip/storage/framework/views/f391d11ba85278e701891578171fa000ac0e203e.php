    
    <?php $__env->startSection('title','Online Learning System : KBTC'); ?>
    <?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <div class="menu-sidebar__content js-scrollbar1">
            <nav class="navbar-sidebar">
                <div class="nav-left-sidebar sidebar-dark">
                    <div class="menu-list">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                            <div class="collapse navbar-collapse" id="navbarNav">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 last-item">
                                    <div class="section-block">
                                        <h3 >Chat List</h3>
                                    </div>
                                    <div class="card mb-2 text">
                                        <div class="card-header " id="headingThree">
                                            <!-- <input class="form-control" type="text" placeholder="Search..">
                                            <h5 class="mb-0"></h5> -->
                                        </div>
                                        <div class="card">
                                            <div class="list-group chat-list" id="list-tab" role="tablist">
                                                <?php if(isset($users)): ?>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a class="chat-list-user list-group-item list-group-item-action" id="<?php echo e($user->id); ?>" data-toggle="list" href="#<?php echo e($user->id); ?>" role="tab" aria-controls="home">
                                                    <img src="http://localhost:8000/images/p1.jpg" alt="User Avatar" class="rounded-circle user-avatar float-left" width="50" height="50"><p class="text-center"><?php echo e($user->name); ?>

                                                    <?php if($user->pending > 0): ?>
                                                    <i class="far fa-bell fa-lg float-right"><span class="pending float-right"><?php echo e($user->pending); ?></span></i>
                                                    <?php endif; ?></p>
                                                    <span class=" float-right">Tuesday, April 21, 2020 </span>
                                                </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>  
                                        </div>
                                        <div class="card-footer">
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#create-con" id="btn-create-new-con">Create a new conversion</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <div class="dashboard-wrapper-1" id="messages">
    </div>
    
<!-- Modal -->
<div class="modal fade" id="create-con" tabindex="-1" role="dialog" aria-labelledby="create-con" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="create-con">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
            <div class="col-12">
                        <form>
          <!-- <div class="form-group">
            <label for="recipient-name" class="col-form-label">Recipient:</label>
            <input type="text" class="form-control" id="recipient-name">
          </div> -->
          
        <?php if(isset($students)): ?>
        
        <div class="list-group con-list overflow-auto" id="con-list" style="max-height:200px;">
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#<?php echo e($student->id); ?>" role="tab" aria-controls="profile">
      <img src="http://localhost:8000/images/p1.jpg" alt="User Avatar" class="rounded-circle user-avatar-sm">&nbsp;&nbsp;<?php echo e($student->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
            <?php endif; ?>
            <div class="form-group">
                <label for="message-text" class="col-form-label">Message:</label>
                <textarea class="form-control" id="new-message-text" placeholder="Type a new message..."></textarea>
            </div>
        </form>
            </div>            
        </div>
        <div class="row">
            <div class="col-12 error">
                <p class="text-center text-danger d-none">Could not create new conversation !!!</p>
            </div>
        </div>

      </div>
      <div class="modal-footer">
        <div class="row">
            <div class="col-12">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" id="btn-create-con">Create conversion</button>
            </div>
            
        </div>
      </div>
    </div>
  </div>
</div>
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"> -->


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('lecturer.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zaya\OneDrive\KBTC\online learning\online_learning\resources\views/lecturer/pages/chat.blade.php ENDPATH**/ ?>